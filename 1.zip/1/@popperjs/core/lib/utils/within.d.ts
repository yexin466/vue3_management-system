export declare function within(min: number, value: number, max: number): number;
export declare function withinMaxClamp(min: number, value: number, max: number): number;
