import { escape } from "./index";
export = escape;
