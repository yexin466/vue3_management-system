import { eachRight } from "./index";
export = eachRight;
