import { forEachRight } from "./index";
export = forEachRight;
