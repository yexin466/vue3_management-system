import { attempt } from "./index";
export = attempt;
