import _ = require("../index");
declare const placeholder: _.__;
export = placeholder;
