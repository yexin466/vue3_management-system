import { assoc } from "../fp";
export = assoc;
