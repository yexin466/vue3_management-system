import { nth } from "../fp";
export = nth;
