import { ary } from "../fp";
export = ary;
