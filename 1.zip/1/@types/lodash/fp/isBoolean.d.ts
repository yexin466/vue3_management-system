import { isBoolean } from "../fp";
export = isBoolean;
