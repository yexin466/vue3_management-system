import { kebabCase } from "../fp";
export = kebabCase;
