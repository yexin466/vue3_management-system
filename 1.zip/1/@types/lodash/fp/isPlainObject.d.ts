import { isPlainObject } from "../fp";
export = isPlainObject;
