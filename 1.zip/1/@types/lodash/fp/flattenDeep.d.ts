import { flattenDeep } from "../fp";
export = flattenDeep;
