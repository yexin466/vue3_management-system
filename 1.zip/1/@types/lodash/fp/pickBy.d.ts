import { pickBy } from "../fp";
export = pickBy;
