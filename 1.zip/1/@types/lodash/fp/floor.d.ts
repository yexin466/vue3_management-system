import { floor } from "../fp";
export = floor;
