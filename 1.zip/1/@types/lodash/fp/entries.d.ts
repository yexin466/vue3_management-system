import { entries } from "../fp";
export = entries;
