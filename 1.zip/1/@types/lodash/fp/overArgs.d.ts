import { overArgs } from "../fp";
export = overArgs;
