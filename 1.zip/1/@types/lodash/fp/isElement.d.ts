import { isElement } from "../fp";
export = isElement;
