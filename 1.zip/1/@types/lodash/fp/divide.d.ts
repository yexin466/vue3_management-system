import { divide } from "../fp";
export = divide;
