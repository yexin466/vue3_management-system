import { add } from "../fp";
export = add;
