import { isMap } from "../fp";
export = isMap;
