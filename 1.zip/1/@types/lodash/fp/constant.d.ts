import { constant } from "../fp";
export = constant;
