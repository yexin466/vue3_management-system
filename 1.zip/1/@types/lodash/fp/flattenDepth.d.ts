import { flattenDepth } from "../fp";
export = flattenDepth;
