# Installation
> `npm install --save @types/estree`

# Summary
This package contains type definitions for estree (https://github.com/estree/estree).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree.

### Additional Details
 * Last updated: Mon, 24 Mar 2025 07:34:10 GMT
 * Dependencies: none

# Credits
These definitions were written by [RReverser](https://github.com/RReverser).
