<script setup>
 
</script>

<template>
  <div>商品</div>
</template>

<style scoped lang="less">
  
</style>