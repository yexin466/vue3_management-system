<script setup>
// import { ElButton } from 'element-plus'
// export default {
//   components: { ElButton },
// }
</script>
<template>
  <router-view></router-view>
</template>


<style scoped>
#app{
  width: 100%;
  height: 100%;
  overflow: hidden;
}
/* 全局显示，防止滚动条的出现 */
</style>
