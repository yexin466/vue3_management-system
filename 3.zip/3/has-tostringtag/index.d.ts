declare function hasToStringTag(): boolean;

export = hasToStringTag;
