Tests are generally organized in the `less/` folder by what options are set in index.js.

The main tests are located under `less/_main/`