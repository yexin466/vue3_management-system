import { ExecuteValidator } from '../interface';
declare const enumerable: ExecuteValidator;
export default enumerable;
