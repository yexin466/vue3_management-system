declare const _default: () => RegExp;
export default _default;
