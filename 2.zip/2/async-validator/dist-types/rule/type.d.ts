import { ExecuteRule } from '../interface';
declare const type: ExecuteRule;
export default type;
